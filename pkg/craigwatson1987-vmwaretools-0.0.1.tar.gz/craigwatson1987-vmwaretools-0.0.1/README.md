puppet-vmwaretools
==================

Puppet module for non-OSP VMware Tools Installation.

To use the module, place your VMware Tools .tar.gz file within the module's files directory and adjust params.pp as necessary.

NOTE: This module is designed to replace both the OSP packages provided by VMware's repositories and also the open-vm-tools package.

Currently only tested on Ubuntu 12.04 server.
